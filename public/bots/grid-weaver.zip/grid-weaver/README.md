# Grid Weaver — SoDEX paper trading bot

Symmetric grid on the live mark price: buys each 0.4% rung down, sells it one rung up.

**Paper mode.** Simulated fills and a simulated balance against LIVE SoDEX
market data. It never asks for keys and physically cannot place real orders —
there is no signing code in this package.

## Quick start

```
# 1. Python 3.10+ is the only requirement — no pip installs.
python --version

# 2. (optional) copy the config and tune it
cp .env.example .env

# 3. run
python bot.py            # XRP-USD grid
python bot.py DOGE-USD
```

Stop with Ctrl-C — state is saved atomically and the bot resumes exactly where
it stopped (open position included) on the next run.

## What's in the box

| File | Purpose |
| --- | --- |
| `bot.py` | The strategy. Read it — it's short and it is the whole edge. |
| `core/sodex_api.py` | REST client: retries + backoff, hard timeouts, kline ordering guaranteed oldest→newest with the forming candle dropped. |
| `core/broker.py` | Decimal-exact paper broker: margin, taker fees, exchange min-qty/step/notional enforcement, simulated liquidation. |
| `core/risk.py` | Risk manager: max-drawdown kill switch, daily loss limit, loss-streak cooldown, notional cap, equity floor. |
| `core/runner.py` | Main loop: config, resume-on-restart, graceful shutdown, status line. |
| `core/state.py` | Atomic `state.json`, append-only `trades.csv`, `equity.jsonl`. |
| `.env.example` | Every tunable parameter, documented. |

## Outputs (in `data/`)

* `…-trades.csv` — every fill: time, side, qty, price, fee, PnL, balance.
* `…-equity.jsonl` — one equity mark per poll, chartable.
* `…-state.json` — the resumable account state. Delete it to start fresh.
* `….log` — full run log.

## Risk manager defaults

| Limit | Default | Meaning |
| --- | --- | --- |
| `MAX_DRAWDOWN_PCT` | 20 | Kill switch on peak-to-trough equity drawdown. |
| `DAILY_LOSS_LIMIT_PCT` | 6 | Done for the UTC day after losing this much. |
| `MAX_CONSEC_LOSSES` / `COOLDOWN_MIN` | 5 / 60 | Losing streak → timed stand-down. |
| `MAX_POSITION_NOTIONAL_USD` | 5000 | Hard per-position cap. |
| `EQUITY_FLOOR_USD` | 5000 | Absolute floor → kill switch. |

Once the kill switch trips, the bot refuses new entries even across restarts
(the flag persists in `state.json`) — restarting a blown account must be a
deliberate act: delete `data/…-state.json`.

## Disclaimer

Simulated performance is not real performance. Fills happen at candle closes
or the mark price with taker fees and no slippage or queue modelling. This
package is educational; nothing in it is financial advice.
